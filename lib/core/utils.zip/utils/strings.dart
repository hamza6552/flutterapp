class UIStrings {
  // Failure message
  static const String serverFailureMessage = 'Server failure';
  static const String cacheFailureMessage = 'Cache failure';
  static const String internetFailureMessage = 'No internet connection';
  static const String defaultFailureMessage = 'Unexpected error';
}
